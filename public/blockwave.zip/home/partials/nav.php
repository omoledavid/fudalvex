<li><a href="/">Home</a></li>
<li><a href="login">Login</a></li>
<li><a href="register">Register</a></li>
<li><a href="why-us.php">Why <?= $domain ?></a></li>
<li><a href="about.php">About us</a></li>
<li><a href="contact.php">Customer service</a></li>
<li><a href="faqs.php">FAQs</a></li>