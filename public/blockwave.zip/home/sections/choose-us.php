<section class="wow fadeIn cover-background sm-no-background-img bg-light-gray" style="background-image: url('home/asset/images/big.jpg')">
    <div class="container">
        <div class="row equalize sm-equalize-auto">
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 pull-right wow fadeIn">
                <div class="display-table-cell vertical-align-middle">
                    <h5 class="alt-font text-extra-dark-gray font-weight-400">Why <span class="text-red">Choose</span> Us</h5>
                    <p class="text-extra-dark-gray alt-font"><?= $domain ?> strives to be worthy of our client's trust by providing them with services which are economically beneficial to them and to create awareness regarding reliable and highly profitable investment platform among our clients around the globe. All you need to do is sit back and enjoy how your profit grows on a daily.</p>
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-6  text-extra-dark-gray">
                            <ul class="no-padding list-style-3">
                                <li>Professional team</li>
                                <li>Instant payments</li>
                                <li>24/7 live support</li>
                                <li>Great referral system</li>
                            </ul>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-6 text-extra-dark-gray">
                            <ul class="no-padding list-style-3">
                                <li>DDOS security</li>
                                <li>Unique design</li>
                                <li>Profitable plans</li>
                                <li>No investment contracts</li>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</section>