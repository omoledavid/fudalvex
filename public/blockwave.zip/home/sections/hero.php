<section class="wow fadeIn no-padding main-slider height-100 mobile-height cover-background" style="background:url('home/asset/images/Forex.jpg'); background-repeat: no-repeat;">
    <div class="opacity-extra-medium bg-black"></div>
    <div class="container position-relative full-screen">
        <div class="col-md-12 slider-typography text-left xs-text-left">
            <div class="slider-text-middle-main">
                <div class="slider-text-middle">
                    <h5 class="alt-font text-white font-weight-400 letter-spacing-minus-1 width-50 margin-35px-bottom md-width-60 sm-width-70 md-line-height-auto xs-width-100 xs-margin-15px-bottom"> <?= $domain ?> - The Leading Online Trade Center</h5>
                    <p class="text-white text-large margin-four-bottom width-40 md-width-50 sm-width-60 xs-width-100 xs-margin-15px-bottom alt-font">Forex & Bitcoin Trading. Invest in Crypto, Dollar, Stocks and keep standing tall no matter the strength of the Economy.</p>
                    <a href="user/registration" _blank" class="btn btn-primary border-radius-4 btn-small no-margin-lr">Join Now</a>


                </div>

            </div>
        </div>
    </div>

</section>