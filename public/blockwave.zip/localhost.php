<?php
$domain = 'Block WavePlus';
$phone = 522828828288;
$email = 'support@block-wave.com';